# The blog link:

To know in detail about the project please click [here](https://medium.com/@samarthagldev/barclays-hack-o-hire-2024-hackathon-experience-c5877e93ca43).

You can follow this link if the above doesn't work: https://medium.com/@samarthagldev/barclays-hack-o-hire-2024-hackathon-experience-c5877e93ca43
